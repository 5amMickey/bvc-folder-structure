# Location 02: L'Alto
